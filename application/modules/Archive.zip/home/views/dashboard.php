<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>




<section class="content">
      <!-- Small boxes (Stat box) -->
      <center>
        <br><br>
          <img src="<?= base_url()?>assets/front/x.png" alt="" style="width:150px;">
          <br>
                <p>
                   <h3>DESA KABUBU </h3><b><br>
                   KECAMATAN TOPOYO<br> KABUPATEN MAMUJU TENGAH
                   <br> PROVINSI SULAWESI BARAT</b>
                </p>
             </center>


</section>
