<?= preloader(); ?>

<section class="content-header">
  <h1>
    Selamat Datang
    <small></small>
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <!-- Small boxes (Stat box) -->
  <div class="container">


    <div class="row">

    </div>
    </div>
    </div>

</section>
<!-- /.content -->
